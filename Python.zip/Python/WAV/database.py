
import sqlite3
import datetime
from typing import List, Dict, Any, Optional

class WAVDatabase:
    def __init__(self, db_path="wav_data.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize the database with required tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                age INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Search history table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS search_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                query TEXT NOT NULL,
                results_summary TEXT,
                search_type TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Conversations table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                user_input TEXT NOT NULL,
                ai_response TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def add_user(self, name: str, age: int) -> int:
        """Add a new user and return their ID"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO users (name, age) VALUES (?, ?)",
            (name, age)
        )
        user_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return user_id
    
    def log_search(self, user_id: int, query: str, results_summary: str, search_type: str):
        """Log a search query and its results"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO search_history (user_id, query, results_summary, search_type) VALUES (?, ?, ?, ?)",
            (user_id, query, results_summary, search_type)
        )
        conn.commit()
        conn.close()
    
    def log_conversation(self, user_id: int, user_input: str, ai_response: str):
        """Log a conversation exchange"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO conversations (user_id, user_input, ai_response) VALUES (?, ?, ?)",
            (user_id, user_input, ai_response)
        )
        conn.commit()
        conn.close()
    
    def get_user_search_history(self, user_id: int, limit: int = 10) -> List[Dict]:
        """Get recent search history for a user"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT query, results_summary, search_type, created_at FROM search_history WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
            (user_id, limit)
        )
        
        results = []
        for row in cursor.fetchall():
            results.append({
                'query': row[0],
                'summary': row[1],
                'type': row[2],
                'timestamp': row[3]
            })
        
        conn.close()
        return results
    
    def get_user_by_name(self, name: str) -> Optional[Dict]:
        """Get user by name"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT id, name, age, created_at FROM users WHERE name = ? ORDER BY created_at DESC LIMIT 1",
            (name,)
        )
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return {
                'id': row[0],
                'name': row[1],
                'age': row[2],
                'created_at': row[3]
            }
        return None
