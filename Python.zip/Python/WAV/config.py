
import os
from typing import Dict, Any

class WAVConfig:
    """Configuration management for WAV Assistant"""
    
    def __init__(self):
        self.settings = {
            # Search settings
            'max_search_results': 3,
            'search_timeout': 5,
            'fallback_to_web': True,
            'use_wikipedia_first': True,
            
            # Response settings
            'max_response_length': 500,
            'include_sources': True,
            'use_emojis': True,
            'detailed_responses': True,
            
            # Database settings
            'db_path': 'wav_data.db',
            'log_conversations': True,
            'log_searches': True,
            
            # API settings
            'request_timeout': 10,
            'retry_attempts': 2,
            'user_agent': 'WAV-Assistant/1.0',
            
            # Feature flags
            'enable_news_search': True,
            'enable_weather_search': False,  # Would need API key
            'enable_stock_search': False,    # Would need API key
            'debug_mode': False
        }
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value"""
        return self.settings.get(key, default)
    
    def set(self, key: str, value: Any) -> None:
        """Set configuration value"""
        self.settings[key] = value
    
    def update_from_env(self) -> None:
        """Update settings from environment variables"""
        env_mappings = {
            'WAV_DEBUG': ('debug_mode', bool),
            'WAV_MAX_RESULTS': ('max_search_results', int),
            'WAV_TIMEOUT': ('search_timeout', int),
            'WAV_DB_PATH': ('db_path', str)
        }
        
        for env_var, (setting_key, type_func) in env_mappings.items():
            env_value = os.getenv(env_var)
            if env_value is not None:
                try:
                    if type_func == bool:
                        self.settings[setting_key] = env_value.lower() in ('true', '1', 'yes')
                    else:
                        self.settings[setting_key] = type_func(env_value)
                except (ValueError, TypeError):
                    print(f"⚠️ Invalid value for {env_var}: {env_value}")
    
    def get_search_config(self) -> Dict[str, Any]:
        """Get search-specific configuration"""
        return {
            'max_results': self.get('max_search_results'),
            'timeout': self.get('search_timeout'),
            'fallback_to_web': self.get('fallback_to_web'),
            'use_wikipedia_first': self.get('use_wikipedia_first')
        }
    
    def get_response_config(self) -> Dict[str, Any]:
        """Get response-specific configuration"""
        return {
            'max_length': self.get('max_response_length'),
            'include_sources': self.get('include_sources'),
            'use_emojis': self.get('use_emojis'),
            'detailed': self.get('detailed_responses')
        }

# Global configuration instance
config = WAVConfig()
config.update_from_env()
