# agent_tools.py
from ddgs import DDGS
import datetime
import random
import requests
from zoneinfo import ZoneInfo
import json

def ask_llm_should_search(user_input):
    """Improved search decision logic with explicit commands"""
    query = user_input.lower()

    # Explicit search commands
    if query.startswith(('search ', 'web search ', 'look up ', 'find ')):
        return "YES"

    # Don't search for basic info queries that can be answered directly
    direct_answer_keywords = ['time', 'date', 'day', 'year', 'hello', 'hi', 'thanks', 'thank you', 'how are you', 'good morning', 'good afternoon', 'good evening']
    if any(keyword in query for keyword in direct_answer_keywords):
        return "NO"

    # Auto-search for these types of queries that likely need real-time data
    auto_search_keywords = ['news', 'weather', 'price', 'stock', 'latest', 'current events', 'what happened', 'bitcoin', 'crypto', 'breaking']
    if any(keyword in query for keyword in auto_search_keywords):
        return "YES"

    # For other queries, ask the user if they want to search
    return "ASK"

def search_web(query, num_results=1):
    """Search the web using DuckDuckGo with improved query formatting"""
    try:
        # Clean and improve the query for better results
        clean_query = query.strip()

        print(f"🔍 Searching for: {clean_query}")

        ddgs = DDGS()
        results = list(ddgs.text(clean_query, max_results=5))

        if not results:
            print("⚠️ No results found, trying alternative search...")
            # Try a simplified query
            simple_query = ' '.join(clean_query.split()[:3])  # Use first 3 words
            results = list(ddgs.text(simple_query, max_results=5))

        # Filter out less relevant results
        filtered_results = []
        for result in results:
            title_lower = result.get('title', '').lower()
            body_lower = result.get('body', '').lower()

            # Skip thesaurus, synonym, and irrelevant sites
            skip_keywords = ['thesaurus', 'synonyms', 'antonyms', 'dictionary.com', 'ads', 'shopping']
            if not any(skip in title_lower or skip in body_lower for skip in skip_keywords):
                filtered_results.append(result)

            if len(filtered_results) >= num_results:
                break

        print(f"✅ Found {len(filtered_results)} relevant results")
        return filtered_results[:num_results]

    except Exception as e:
        print(f"Search error: {e}")
        return []

def summarize_results(results):
    """Simple summary of search results"""
    if not results:
        return "No results found."

    if len(results) == 1:
        result = results[0]
        summary = f"Top result:\n{result['title']}\n{result['body'][:150]}...\n"
    else:
        summary = f"Found {len(results)} results:\n"
        for i, result in enumerate(results[:1], 1):
            summary += f"{i}. {result['title']}\n   {result['body'][:150]}...\n"

    return summary

def get_accurate_time():
    """Get accurate time from web API as fallback"""
    try:
        response = requests.get("http://worldtimeapi.org/api/timezone/America/New_York", timeout=3)
        if response.status_code == 200:
            data = response.json()
            utc_time = datetime.datetime.fromisoformat(data['datetime'].replace('Z', '+00:00'))
            return utc_time.strftime("%I:%M:%S %p %Z")
    except:
        pass
    return None

def search_wikipedia(query, sentences=3):
    """Search Wikipedia for accurate information"""
    try:
        # First search for the page
        search_url = f"https://en.wikipedia.org/api/rest_v1/page/search/{query}"
        search_response = requests.get(search_url, timeout=5)

        if search_response.status_code == 200:
            search_data = search_response.json()
            if 'pages' in search_data and len(search_data['pages']) > 0:
                # Get the first result's key
                page_key = search_data['pages'][0]['key']

                # Get the summary for that page
                summary_url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{page_key}"
                summary_response = requests.get(summary_url, timeout=5)

                if summary_response.status_code == 200:
                    data = summary_response.json()
                    if 'extract' in data and data['extract']:
                        extract = data['extract']
                        # Limit to specified number of sentences
                        sentences_list = extract.split('. ')
                        limited_extract = '. '.join(sentences_list[:sentences])
                        if not limited_extract.endswith('.'):
                            limited_extract += '.'

                        return {
                            'title': data.get('title', ''),
                            'extract': limited_extract,
                            'url': data.get('content_urls', {}).get('desktop', {}).get('page', ''),
                            'source': 'Wikipedia'
                        }
    except Exception as e:
        print(f"Wikipedia search error: {e}")
    return None

def get_current_news(topic):
    """Get current news about a topic using a free news API"""
    try:
        # Using a free news API (no key required)
        url = f"https://api.worldnewsapi.com/search-news?text={topic}&number=1"
        response = requests.get(url, timeout=5)

        if response.status_code == 200:
            data = response.json()
            if 'news' in data and data['news']:
                article = data['news'][0]
                return {
                    'title': article.get('title', ''),
                    'summary': article.get('summary', '')[:200] + '...',
                    'source': article.get('source', 'News'),
                    'url': article.get('url', '')
                }
    except:
        # Fallback to web search for news
        pass
    return None

def get_direct_answer(user_input):
    """Provide direct answers for basic queries"""
    query = user_input.lower()

    # Get current time with timezone awareness
    try:
        # Try to use local timezone, fallback to UTC if not available
        try:
            local_tz = ZoneInfo("America/New_York")  # You can change this to your timezone
            now = datetime.datetime.now(local_tz)
        except:
            now = datetime.datetime.now()
    except:
        now = datetime.datetime.now()

    # Time-related queries
    if any(word in query for word in ['time', 'what time']):
        # Try to get accurate time from web API first
        web_time = get_accurate_time()
        if web_time:
            return f"The current time is {web_time} (from web API)."
        else:
            # Fallback to system time
            current_time = now.strftime("%I:%M:%S %p")
            timezone_info = now.strftime("%Z") if hasattr(now, 'tzinfo') and now.tzinfo else ""
            if timezone_info:
                return f"The current time is {current_time} {timezone_info} (system time)."
            else:
                return f"The current time is {current_time} (system time)."

    # Date-related queries
    elif any(word in query for word in ['date', 'what date', 'today']):
        current_date = now.strftime("%B %d, %Y")
        return f"Today's date is {current_date}."

    # Day-related queries
    elif any(word in query for word in ['day', 'what day']):
        current_day = now.strftime("%A")
        return f"Today is {current_day}."

    # Greetings and conversational responses
    elif any(word in query for word in ['hello', 'hi', 'hey']):
        responses = ["Hello! How can I help you today?", "Hi there! What would you like to know?", "Hey! I'm here to help with your questions."]
        return random.choice(responses)

    elif any(word in query for word in ['how are you', 'how do you do']):
        return "I'm doing great! I'm here and ready to help you with information and searches. How can I assist you?"

    elif any(word in query for word in ['thanks', 'thank you']):
        return "You're welcome! Feel free to ask me anything else."

    elif any(word in query for word in ['good morning']):
        return "Good morning! Hope you're having a great day. What can I help you with?"

    elif any(word in query for word in ['good afternoon']):
        return "Good afternoon! What would you like to know today?"

    elif any(word in query for word in ['good evening']):
        return "Good evening! How can I assist you tonight?"

    return None

def enhanced_llm_response(user_input, context=""):
    """Generate a response with direct answers or search context"""
    # Check for direct answers first
    direct_answer = get_direct_answer(user_input)
    if direct_answer:
        return direct_answer

    if context:
        return f"Based on the search results:\n\n{context}\n\nFor more detailed information, you can check the sources above."
    else:
        # More helpful fallback responses
        query = user_input.lower()
        if any(word in query for word in ['what', 'how', 'why', 'when', 'where', 'who']):
            return "I'd love to help you with that question! While I don't have that specific information without searching, I can search the web for current information. Try asking me to 'search for' your topic."
        else:
            return "I understand what you're asking. For the most accurate and up-to-date information, I can search the web for you. Try rephrasing with 'search for' or 'find' at the beginning of your question."

def agent_handle_request(user_input, user_id=None, db=None):
    """Handle user requests with direct answers or web search"""
    try:
        # Check if we can answer directly first
        direct_answer = get_direct_answer(user_input)
        if direct_answer:
            print("⏰ Answering directly...")
            print(f"\n🤖 Response: {direct_answer}")

            if db and user_id:
                db.log_conversation(user_id, user_input, direct_answer)
            return

        should_search = ask_llm_should_search(user_input)

        if should_search == "YES":
            # Clean the query if it starts with search commands
            clean_query = user_input.lower()
            for prefix in ['search ', 'web search ', 'look up ', 'find ']:
                if clean_query.startswith(prefix):
                    clean_query = user_input[len(prefix):]
                    break
            else:
                clean_query = user_input

            # Try Wikipedia first for factual/educational queries
            wiki_keywords = ['who', 'what is', 'history of', 'discovered', 'invented', 'theory', 'principle']
            use_wikipedia = any(keyword in clean_query.lower() for keyword in wiki_keywords)

            if use_wikipedia:
                print("📚 Searching Wikipedia for accurate information...")
                wiki_result = search_wikipedia(clean_query)
                if wiki_result:
                    print(f"\n📖 Wikipedia Result:")
                    print(f"Title: {wiki_result['title']}")
                    print(f"Summary: {wiki_result['extract']}")
                    print(f"Source: {wiki_result['url']}")

                    # Use encoder for better formatting
                    enhanced_response = encoder.create_factual_response(
                        wiki_result['title'],
                        wiki_result['extract'],
                        wiki_result['url']
                    )
                    print(f"\n🤖 Response: {enhanced_response}")

                    if db and user_id:
                        db.log_search(user_id, user_input, f"Wikipedia: {wiki_result['title']}", "wikipedia")
                        db.log_conversation(user_id, user_input, enhanced_response)
                    return

            print("🔎 Searching the web...")
            results = search_web(clean_query)
            if results:
                summary = summarize_results(results)
                print("\n📄 Search Results:")
                print(summary)

                # Enhanced response with search context
                enhanced_response = enhanced_llm_response(user_input, summary)
                print("\n🤖 Response:", enhanced_response)

                # Log to database if available
                if db and user_id:
                    db.log_search(user_id, user_input, summary, "web_search")
                    db.log_conversation(user_id, user_input, enhanced_response)
            else:
                print("No results found.")
                fallback_response = enhanced_llm_response(user_input)
                print("\n🤖 Response:", fallback_response)

                if db and user_id:
                    db.log_conversation(user_id, user_input, fallback_response)

        elif should_search == "ASK":
            # Give user the option to search the web
            print("💡 I can provide a basic response or search the web for more current information.")
            web_choice = input("Would you like me to search the web? (y/n): ").lower().strip()

            if web_choice in ['y', 'yes', 'yeah', 'yep']:
                # Try Wikipedia first for factual queries
                wiki_keywords = ['who', 'what is', 'history of', 'discovered', 'invented', 'theory', 'principle']
                use_wikipedia = any(keyword in user_input.lower() for keyword in wiki_keywords)

                if use_wikipedia:
                    print("📚 Searching Wikipedia...")
                    wiki_result = search_wikipedia(user_input)
                    if wiki_result:
                        print(f"\n📖 Wikipedia Result:")
                        print(f"Title: {wiki_result['title']}")
                        print(f"Summary: {wiki_result['extract']}")
                        print(f"Source: {wiki_result['url']}")

                        # Use encoder for better formatting
                        enhanced_response = encoder.create_factual_response(
                            wiki_result['title'],
                            wiki_result['extract'],
                            wiki_result['url']
                        )
                        print(f"\n🤖 Response: {enhanced_response}")

                        if db and user_id:
                            db.log_search(user_id, user_input, f"Wikipedia: {wiki_result['title']}", "wikipedia")
                            db.log_conversation(user_id, user_input, enhanced_response)
                        return

                print("🔎 Searching the web...")
                results = search_web(user_input)
                if results:
                    summary = summarize_results(results)
                    print("\n📄 Search Results:")
                    print(summary)

                    enhanced_response = enhanced_llm_response(user_input, summary)
                    print("\n🤖 Response:", enhanced_response)

                    if db and user_id:
                        db.log_search(user_id, user_input, summary, "web_search")
                        db.log_conversation(user_id, user_input, enhanced_response)
                else:
                    print("No results found.")
                    fallback_response = enhanced_llm_response(user_input)
                    print("\n🤖 Response:", fallback_response)
                    if db and user_id:
                        db.log_conversation(user_id, user_input, fallback_response)
            else:
                print("💡 Generating basic response...")
                response = enhanced_llm_response(user_input)
                print("\n🤖 Response:", response)
                if db and user_id:
                    db.log_conversation(user_id, user_input, response)
        else:
            print("💡 Generating response...")
            response = enhanced_llm_response(user_input)
            print("\n🤖 Response:", response)

            if db and user_id:
                db.log_conversation(user_id, user_input, response)
    except Exception as e:
        print(f"❌ Error processing request: {e}")
        print("Please try again with a different query.")