
from agent_tools import agent_handle_request  # ← Import AI agent
from database import WAVDatabase  # ← Import database

user_info = {}
db = WAVDatabase()  # Initialize database

def user_data(data):
    if data == 's':
        user_info['name'] = 'Anonymous'
    else:
        user_info['name'] = data.lower()
    
    # Check if user exists in database
    existing_user = db.get_user_by_name(user_info['name'])
    if existing_user:
        user_info['id'] = existing_user['id']
        user_info['age'] = existing_user['age']
        print(f"Welcome back, {user_info['name'].title()}!")
        
        # Show recent search history
        history = db.get_user_search_history(user_info['id'], 3)
        if history:
            print("📚 Your recent searches:")
            for item in history:
                print(f"  • {item['query']} ({item['timestamp'][:10]})")
    else:
        print(f"Hello {user_info['name'].title()}")
        # Only ask for age if this is a new user
        user_age = int(input("How old are you? "))
        if not age_avg(user_age):
            exit()

def age_avg(age):   
    if age < 16:
        print("You're not old enough to use this program")
        return False
    else:
        user_info['age'] = age
        
        # Save user to database if new
        if 'id' not in user_info:
            user_info['id'] = db.add_user(user_info['name'], age)
            print("✅ Profile created and saved!")
        
        print("Let's get started")
        return True

def user_action(request):
    if request.lower() == 'exit':
        print("Goodbye!")
        exit()

    elif request.lower() == 'history':
        if 'id' in user_info:
            history = db.get_user_search_history(user_info['id'], 10)
            if history:
                print("\n📚 Your search history:")
                for i, item in enumerate(history, 1):
                    print(f"{i}. {item['query']} - {item['timestamp'][:16]}")
            else:
                print("No search history found.")
        else:
            print("Please complete registration first.")

    elif request.strip() == '':
        print("Please enter a command or question.")

    else:
        # Send all non-empty requests to the AI agent for better handling
        print("Sending request to AI Agent...")
        agent_handle_request(request, user_info.get('id'), db)
