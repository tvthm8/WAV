
from wavfunc1 import user_data, age_avg, user_action

# Initial setup - only ask for name initially
user_input = input("Hello my name is WAV, what is your name? Press S to skip: ").lower()
user_data(user_input)

# Main interaction loop
print("\n" + "="*50)
print("WAV Assistant is ready! Here are your options:")
print("• Type 'exit' to quit")
print("• Type 'history' to see past searches")
print("• Start with 'search' to force web search (e.g., 'search colleges in Georgia')")
print("• Ask any question - I'll offer web search when helpful")
print("="*50)

while True:
    request = input("\nWhat would you like to do? ")
    user_action(request)
