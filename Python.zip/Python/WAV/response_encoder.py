
import json
import re
from typing import Dict, List, Any
import html

class ResponseEncoder:
    """Encoder/Decoder system for better response processing"""
    
    def __init__(self):
        self.response_templates = {
            'factual': "📚 **{title}**\n\n{content}\n\n🔗 Source: {source}",
            'search': "🔍 **Search Results for: {query}**\n\n{results}\n\n💡 {suggestion}",
            'conversational': "🤖 {response}",
            'error': "❌ {error_type}: {message}\n\n💡 Try: {suggestion}",
            'time': "⏰ {time_info}",
            'greeting': "👋 {greeting_message}"
        }
        
        self.input_patterns = {
            'time_query': r'\b(time|what time|current time)\b',
            'date_query': r'\b(date|what date|today|current date)\b',
            'search_explicit': r'^(search|find|look up|web search)\s+(.+)',
            'factual_query': r'\b(who|what|when|where|why|how)\b',
            'greeting': r'\b(hello|hi|hey|good morning|good afternoon|good evening)\b',
            'thanking': r'\b(thanks|thank you|thx)\b'
        }
    
    def encode_input(self, user_input: str) -> Dict[str, Any]:
        """Encode user input to determine intent and extract key information"""
        cleaned_input = self.clean_input(user_input)
        
        intent_data = {
            'original': user_input,
            'cleaned': cleaned_input,
            'intent': self.classify_intent(cleaned_input),
            'entities': self.extract_entities(cleaned_input),
            'urgency': self.determine_urgency(cleaned_input),
            'context_needed': self.needs_context(cleaned_input)
        }
        
        return intent_data
    
    def decode_response(self, response_data: Dict[str, Any], template_type: str = 'conversational') -> str:
        """Decode and format response using appropriate template"""
        if template_type not in self.response_templates:
            template_type = 'conversational'
        
        template = self.response_templates[template_type]
        
        try:
            formatted_response = template.format(**response_data)
            return self.enhance_formatting(formatted_response)
        except KeyError as e:
            # Fallback to simple response if template formatting fails
            return self.response_templates['conversational'].format(
                response=response_data.get('content', str(response_data))
            )
    
    def clean_input(self, text: str) -> str:
        """Clean and normalize user input"""
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text.strip())
        
        # Fix common typos and variations
        text = re.sub(r'\bwho discovered\b', 'who discovered', text, flags=re.IGNORECASE)
        text = re.sub(r'\bwhat is\b', 'what is', text, flags=re.IGNORECASE)
        text = re.sub(r'\bhow to\b', 'how to', text, flags=re.IGNORECASE)
        
        # Handle HTML entities
        text = html.unescape(text)
        
        return text
    
    def classify_intent(self, text: str) -> str:
        """Classify the intent of user input"""
        text_lower = text.lower()
        
        for intent, pattern in self.input_patterns.items():
            if re.search(pattern, text_lower):
                return intent
        
        # Default classification based on question words
        if any(word in text_lower for word in ['who', 'what', 'when', 'where', 'why', 'how']):
            return 'factual_query'
        elif any(word in text_lower for word in ['search', 'find', 'look up']):
            return 'search_explicit'
        else:
            return 'general_query'
    
    def extract_entities(self, text: str) -> Dict[str, List[str]]:
        """Extract entities from text"""
        entities = {
            'topics': [],
            'people': [],
            'places': [],
            'dates': [],
            'organizations': []
        }
        
        # Simple entity extraction patterns
        # Names (capitalized words that aren't at sentence start)
        names = re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', text)
        entities['people'] = [name for name in names if len(name.split()) <= 3]
        
        # Dates
        date_patterns = [
            r'\b\d{1,2}/\d{1,2}/\d{4}\b',
            r'\b\d{4}\b',
            r'\b(today|tomorrow|yesterday)\b'
        ]
        for pattern in date_patterns:
            entities['dates'].extend(re.findall(pattern, text, re.IGNORECASE))
        
        return entities
    
    def determine_urgency(self, text: str) -> str:
        """Determine urgency level of the query"""
        urgent_words = ['urgent', 'immediately', 'asap', 'emergency', 'now', 'quickly']
        moderate_words = ['soon', 'today', 'current', 'latest', 'recent']
        
        text_lower = text.lower()
        
        if any(word in text_lower for word in urgent_words):
            return 'high'
        elif any(word in text_lower for word in moderate_words):
            return 'medium'
        else:
            return 'low'
    
    def needs_context(self, text: str) -> bool:
        """Determine if query needs additional context/search"""
        context_indicators = [
            'current', 'latest', 'recent', 'news', 'today', 'now',
            'price', 'stock', 'weather', 'events', 'happening'
        ]
        
        return any(indicator in text.lower() for indicator in context_indicators)
    
    def enhance_formatting(self, text: str) -> str:
        """Enhance text formatting for better readability"""
        # Add proper spacing around emojis
        text = re.sub(r'([🔍📚🤖❌⏰👋💡🔗📄])', r'\1 ', text)
        text = re.sub(r'\s+', ' ', text)  # Remove extra spaces
        
        # Ensure proper line breaks
        text = re.sub(r'\n\n\n+', '\n\n', text)
        
        return text.strip()
    
    def create_search_response(self, query: str, results: List[Dict], suggestion: str = "") -> str:
        """Create formatted search response"""
        if not results:
            return self.decode_response({
                'error_type': 'No Results',
                'message': 'No search results found',
                'suggestion': 'Try rephrasing your query or use different keywords'
            }, 'error')
        
        formatted_results = []
        for i, result in enumerate(results[:3], 1):
            title = result.get('title', 'No title')
            body = result.get('body', 'No description')[:150] + '...'
            formatted_results.append(f"{i}. **{title}**\n   {body}")
        
        results_text = '\n\n'.join(formatted_results)
        
        return self.decode_response({
            'query': query,
            'results': results_text,
            'suggestion': suggestion or "These results should help answer your question."
        }, 'search')
    
    def create_factual_response(self, title: str, content: str, source: str) -> str:
        """Create formatted factual response"""
        return self.decode_response({
            'title': title,
            'content': content,
            'source': source
        }, 'factual')
